//package com.stackroute.squad.domain;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//import org.neo4j.ogm.annotation.Id;
//import org.neo4j.ogm.annotation.NodeEntity;
//
//@NodeEntity
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
//public class ServiceSkills
//{
//    @Id
//    private long id;
//    private String serviceSkills;
//}
