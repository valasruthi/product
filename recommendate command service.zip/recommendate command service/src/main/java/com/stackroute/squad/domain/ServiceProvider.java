package com.stackroute.squad.domain;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import java.util.List;

@NodeEntity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ServiceProvider
{
    @Id
    private String name;
    private long mobile;
    private String emailId;
    private String domain;
    private String previousProject;
    private double cost;
    @Relationship(type = "have", direction = Relationship.INCOMING)
    private List<RoleSkill> skills;
}
