package com.stackroute.squad.domain;

import lombok.*;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import javax.management.relation.Role;
import java.util.Collections;
import java.util.Date;
import java.util.List;

@NodeEntity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class Idea
{
    @Id
    private long id;
    private String title;
    private String description;
    private String duration;
    private double cost;
//    private String status;
//    private Date postedOn;
//    private String location;
//    @Relationship(type = "belong_to", direction = Relationship.INCOMING)
//    private List<Roles> roleCollections;
    @Relationship(type = "posted", direction = Relationship.INCOMING)
    private IdeaHamster ideaHamster;

}


//@Relationship(type = "ACTOR", direction = Relationship.INCOMING)