package com.stackroute.squad.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import javax.validation.constraints.Max;
import java.util.List;

@NodeEntity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class IdeaHamster
{
    @Id
    private long id;
    private String name;
    private long mobile;
    private String emailId;
//    @Relationship(type = "has", direction = Relationship.INCOMING)
//    List<Idea> ideas;
}
