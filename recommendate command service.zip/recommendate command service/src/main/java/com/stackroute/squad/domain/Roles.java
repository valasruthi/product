package com.stackroute.squad.domain;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import javax.management.relation.Role;
import java.util.List;

@NodeEntity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Roles
{
    @Id
    private long id;
    private String roleName;
//    @Relationship(type = "need", direction = Relationship.INCOMING)
//    private List<RoleSkill> skills;
    private int noOfPeople;
    private int experience;
    @Relationship(type = "requires", direction = Relationship.INCOMING)
    private List<Idea> idea;

}


//@Relationship(type = "ACTOR", direction = Relationship.INCOMING)